extern int printd( int i );
extern void malloc(int i);
/* ce commentaire n'apparaitra pas :D */
int main() {
   int *i;
   int *j;
    
   i=malloc(sizeof(int));
   j=malloc(sizeof(int));

   *i=4;
  
   printd(*i);

   *j=6;
   printd(*j);
   i=i+1;
   *j=*j+(*i);
   printd(*j);
   return 0;
}

