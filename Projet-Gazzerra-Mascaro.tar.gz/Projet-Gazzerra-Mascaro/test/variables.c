/* test minimal pour un compilateur */

int a;
int main() {
  int a;
  int b;
  int *k;
  a = 0;
  b = 1;
  k = &a;
  return 0;
}
